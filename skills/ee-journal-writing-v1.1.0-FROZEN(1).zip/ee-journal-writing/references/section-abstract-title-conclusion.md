# Abstract, Title, and Conclusion

## Conclusion
The Conclusion should close the problem–evidence–contribution loop:
- restate the technical problem at an appropriate level;
- state the answer supported by the paper;
- identify the main contribution(s);
- mention decisive evidence/results where useful;
- state material validity boundaries/limitations when needed.

Do not introduce new methods, results, comparisons, or stronger claims.

## Abstract
Treat the Abstract as a faithful, compact representation of the completed paper, not as marketing copy.

### Compression workflow
Draft the Abstract from the completed manuscript rather than from a blank page:
1. identify the specific problem/context that survives compression;
2. extract the core proposed method/discovery from the body;
3. select the most informative result(s);
4. state only the conclusion/implication actually supported by those results;
5. retain a material boundary only when needed to avoid a misleadingly broad abstract;
6. compress by merging functions and removing redundant background, not by deleting claim-critical qualifiers.

Method detail should be proportional to the paper's contribution: a method-centered paper may need more method detail than an application-centered paper. Target-journal official requirements remain controlling.

Typical information functions, adapted to journal format:
- specific technical problem/context;
- what is proposed or discovered;
- concrete technical distinction/mechanism;
- how it is validated;
- most informative quantitative result(s) when available and appropriate;
- supported implication/contribution.

Do not force a fixed sentence count. Follow target-journal requirements.

### Abstract evidence gate
Every result, number, performance statement, and novelty claim must exist and be supported in the main manuscript.

Avoid empty claims such as “significantly improves performance” when the manuscript contains a meaningful quantitative result that can be stated within the abstract constraints.

For every quantitative “improvement”, verify that the metric direction is technically meaningful and the comparison is unambiguous. Do not convert a proxy result into secondary benefits (for example lifetime, efficiency, flexibility, resilience) unless those benefits are directly evaluated or the causal link is adequately supported in the paper.

## Title
The title is both a scope commitment and a retrieval cue. A useful construction route is: start from the actual research problem/question, identify the technical object and the distinctive method/mechanism when needed, then compress without broadening the claim.

Check:
- technical object/problem is accurate;
- method/mechanism is represented when useful;
- important searchable terminology is present;
- no unsupported `robust`, `optimal`, `real-time`, `general`, `stable`, etc.;
- no ambiguous noun chain or misleading breadth;
- noun-chain modifiers have an unambiguous attachment;
- prepositions express the intended technical relation rather than merely sounding natural;
- terminology matches the manuscript.

Formatting, capitalization, subtitle use, and other title conventions must follow the target journal rather than generic rules.
