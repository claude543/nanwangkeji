# Domain Overlay: Power Electronics and Converters

## Use when
The contribution centers on converter topology, modulation, switching strategy, hardware design, converter control, device stress, loss/efficiency, or hardware implementation.

## Key checks
- topology and operating states are fully interpretable;
- switching/modulation sequence and constraints are reproducible;
- device voltage/current stress claims are quantitatively supported;
- loss/efficiency claims specify calculation or measurement basis and operating range;
- magnetic/filter/passive design assumptions and ratings are clear when relevant;
- sampling, PWM/switching frequency, dead time, delays, protection, and saturation are included when claim-critical;
- hardware specifications and measurement methods support experimental claims;
- prototype voltage/current/power levels, switching frequency, duty range, thermal conditions, efficiency measurement method, protection limits, and instrumentation are reported when they are claim-critical;
- fault-tolerance/reliability claims distinguish demonstrated fault cases from broader reliability claims;
- theoretical component-count or switching-count advantages are not automatically translated into cost, reliability, power-density, or efficiency claims without evidence.

## Common failure modes
- equating fewer devices with lower cost/reliability improvement without analysis;
- claiming efficiency advantage from analytical loss estimates only across an insufficient range;
- omitting implementation details needed to reproduce modulation/control;
- overgeneralizing prototype performance beyond rated/validated operating conditions.
