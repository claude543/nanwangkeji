# Domain Overlay: Control and Algorithms

## Use when
The dominant contribution is a controller, coordinator, estimator, observer, distributed algorithm, optimization/control policy, or related control mechanism.

## Key checks
- control objective and controlled variables are explicit;
- measurements/information available to the controller are distinguished from true physical states;
- control hierarchy and timescales are clear;
- controller state, memory, delays, switching logic, saturation, and constraints are modeled when claim-critical;
- baseline controllers solve a comparable problem with fair information and tuning;
- controller gains/weights are justified enough to reproduce the reported performance;
- stability/convergence/robustness claims use the correct property evidence;
- tracking, overshoot, settling, error norms, or other metrics are defined rather than judged visually;
- implementation feasibility is checked when digital/real-time deployment is claimed.

## Common failure modes
- calling simulation settling a stability proof;
- confusing command/reference with actual device execution;
- treating one disturbance case as robust performance;
- adding observer/optimizer/state machine as separate “contributions” without explaining the new integrated capability;
- using controller information that would not be available in the stated architecture.
