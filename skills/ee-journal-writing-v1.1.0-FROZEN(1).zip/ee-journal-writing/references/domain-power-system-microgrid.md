# Domain Overlay: Power Systems and Microgrids

## Use when
The paper addresses grid/microgrid operation, renewable/storage/EV coordination, AGC, secondary control, scheduling, power flow, stability, distributed energy resources, communication-aware operation, or related system-level problems.

## Key checks
- network/resource configuration and system boundary are explicit;
- PCC/intertie/grid power direction and sign conventions are unambiguous;
- resource limits, SOC/energy limits, renewable availability, load behavior, and relevant reserve/margin definitions are clear;
- SOC claims use an appropriate objective: higher/lower instantaneous SOC is not inherently better; distinguish SOC recovery, bound avoidance, energy availability, reserve margin, cycling stress, and long-horizon energy balance;
- operating points and disturbance scenarios match the claimed application;
- communication assumptions, measurement freshness, delay/loss/interruption, and control-information paths are explicit when relevant;
- system-level claims are separated from device/controller-level observations;
- multi-timescale interactions are not silently collapsed;
- test-system size/topology is adequate for the scope claimed;
- distributed/scalable claims include network/communication or scale evidence;
- uncertainty/renewable/load scenarios are broad enough for any robustness/generalization claim.

## Common failure modes
- generic “microgrid resilience” claims from a narrow tracking test;
- ignoring energy/SOC constraints while claiming sustained coordination capability;
- using ideal communication while presenting a method as communication-resilient;
- treating one benchmark network as evidence of general scalability;
- inconsistent power-flow direction between equations, figures, and prose.
