# Domain Overlay: Modeling, Mechanism, and Stability Analysis

## Use when
The central contribution is a new model, formulation, modal/impedance/energy analysis, stability criterion, mechanism explanation, reduced-order representation, or similar analytical insight.

## Key checks
- model purpose and fidelity level are stated;
- assumptions and neglected dynamics are traceable to the claimed frequency/time/operating range;
- linearization point and perturbation assumptions are explicit when applicable;
- parameter sources/identification procedures are clear;
- mathematical results are connected to physical meaning rather than only presented algebraically;
- validation is sufficiently independent from the derivation/model assumptions;
- agreement with a simulation built from the same assumptions is recognized as self-consistency, not automatically independent physical validation;
- alternative mechanisms/explanations are considered when the evidence does not uniquely identify one;
- stability/mechanism conclusions do not exceed the model's validity domain.

## Common failure modes
- using a reduced model outside its intended frequency/operating range;
- claiming physical causality from modal correlation alone;
- using one operating point to assert universal mechanism behavior;
- calling model–simulation agreement “experimental validation” when both share the same model assumptions.
