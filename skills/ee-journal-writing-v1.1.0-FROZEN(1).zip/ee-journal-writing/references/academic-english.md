# Academic English Realization

## Load last
Apply language optimization only after technical meaning, evidence, and section function are stable enough for the requested task. Language is an implementation layer, not a source of scientific truth.

## User-visible output
Reason internally as needed, but present analytical labels and judgments in Chinese by default. English should appear only when the English wording itself is being taught, compared, corrected, or delivered as manuscript text, or when a technical name/abbreviation must remain exact.

## Sentence function first
Before rewriting, identify what the sentence must do: background, contrast, gap, method rationale, definition, observation, comparison, interpretation, implication, limitation, contribution, figure navigation, etc. Choose grammar and wording to serve that function.

### Sentence deletion test
Ask: if this sentence disappeared, what would the reader lose?
- If the answer is “no technical information, logical relation, evidence, scope boundary, or navigation function”, revise or remove it.
- Do not mechanically delete figure/table invitation sentences, transition sentences, or scope qualifiers if they perform a real reader-guidance function.

## Technical ownership clarity
For method and result statements, make it clear whether the sentence describes:
- this paper's action or contribution;
- prior work;
- a standard/common procedure;
- an inherent system/device/topology property;
- a mathematical relationship;
- an observed result.

Use subject choice, citation placement, tense, voice, and context together. Do **not** impose formulas such as “present tense = standard” or “past tense = this work”. In EE writing, `This paper proposes...`, topology descriptions, mathematical relations, and experiment descriptions can legitimately use different tense/voice patterns.

## Claim strength and causality
Match verbs, modality, qualifiers, and causal language to evidence strength. Do not automatically make prose “stronger”.

Distinguish:
- direct observation from interpretation;
- association/correlation from causal mechanism;
- observed behavior from a proved property;
- study-specific evidence from broader generalization.

When causality is not fully established, reduce the claim through scientifically accurate wording rather than decorative hedging. For example, depending on evidence, `causes` may need to become `is associated with`, `is consistent with`, `may contribute to`, or an equivalent formulation.

Do not stack so many qualifiers that the sentence becomes empty.

## Modality
Words corresponding to possibility, probability, necessity, guarantee, recommendation, and certainty must match the evidence. Treat modality as a representation of confidence or obligation, not a way to manufacture truth.

## Tense and voice
Treat tense and active/passive voice as meaning and journal-style choices, not fixed formulas. A tense change should have a functional reason, such as distinguishing prior work, completed experimental action, current interpretation, or a generally valid relation.

Truth is determined by evidence, not by tense. Target-journal convention may affect preferred realization.

## Paragraph logic
Prefer one dominant paragraph function. A useful internal pattern is:
`topic/claim → evidence/detail → interpretation → transition`.
Use reverse outlining when flow is unclear.

## Cohesion
Use stable technical terms, controlled repetition, pronouns/pro-forms, clause combination, and logical connectors to make relationships explicit. Do not vary terminology merely to avoid lexical repetition if variation harms technical precision.

When Discussion/Conclusion revisits a concept introduced earlier, preserve the key term unless the concept has genuinely changed. Do not introduce a new technical fact merely as part of a callback.

## Connectors
Choose connectors for actual logical relations. Do not replace `however` with a synonym only for stylistic variety if the relation is not genuinely contrastive.

Four useful cohesion mechanisms are:
1. repeat a key technical element when precision benefits;
2. use a clear pronoun/pro-form when reference is unambiguous;
3. combine clauses when the logical relation is tighter than two separate sentences imply;
4. use a connector that names the actual relation (cause, result, contrast, addition, unexpectedness, etc.).

## Precision
Prefer concrete engineering nouns/verbs and quantified comparisons over vague evaluative language. Avoid decorative “advanced vocabulary” that reduces precision.

## Final language checks
- grammar and articles;
- modifier attachment/ambiguity;
- long noun chains;
- pronoun reference;
- sentence length and nested clauses;
- subject–verb agreement;
- consistent abbreviation and terminology;
- concise figure/table references;
- no invented intensifiers or claims;
- no ambiguity over whose method/result a sentence describes;
- no causal or certainty wording stronger than the evidence.
