# Validation Design, Figures/Tables, and Results

## Validation should be claim-driven
Start from each contribution/major claim and derive:
`claim → required evidence → test → scenario → comparator → metric → expected discriminating observation`.

Do not start by accumulating plots and later assigning them a story.


## Validation-lane separation
Before judging whether validation is sufficient, separate the evidence into claim-specific lanes:
1. **Model/formulation validity**: accuracy, fidelity, numerical stability, agreement with an independent reference or data source.
2. **Method/controller performance**: tracking, damping, regulation, efficiency, economic or other task metrics against appropriate baselines.
3. **Theory/property validation**: simulations/experiments illustrate derived properties but do not replace proofs or formal guarantees when those are claimed.
4. **Implementation/real-time feasibility**: execution time, sampling/control period, hardware/HIL platform, synchronization, resource headroom, or prototype behavior.
5. **System-level capability**: scenario breadth, resource/network scale, uncertainty, communication conditions, and sustained operation appropriate to the system-level claim.

Do not use one attractive case study as evidence for all lanes. Map every major claim to the lane(s) it actually needs.

## Baseline fairness
For comparative results check:
- baseline relevance and recency;
- parameter/tuning fairness;
- same operating conditions and constraints;
- same information availability where possible;
- whether a baseline is disadvantaged by an implementation choice unrelated to the contribution.

## Scenario coverage
Select scenarios that probe the conditions included in the claim. Include nominal and stress/edge cases only when relevant. Do not infer generality from a narrow scenario set.

## Simulation reproducibility
When claim-critical, check software/model version if relevant, solver, timestep, switching/control rates, parameters, initialization, random seed/stochastic procedure, disturbances, and measurement definitions.

## Experiment/HIL reproducibility
When claim-critical, check hardware/platform, rated values, sampling/control/communication periods, interface and measurement chain, real-time step, data acquisition, limits/saturation, and synchronization assumptions.


## Metric semantics
Before calling a change an improvement, establish what the metric means for the stated objective. Check:
- desired direction or target range;
- reference/baseline and time window;
- whether absolute change, percentage change, or percentage-point change is intended;
- whether a proxy metric genuinely supports the claimed engineering benefit.

Examples: higher SOC is not inherently better unless the scenario objective is SOC recovery/reserve restoration; lower switching loss does not by itself establish higher system efficiency unless other relevant losses are accounted for.

## Validation-platform nomenclature
Use technically accurate labels and keep them consistent:
- offline/non-real-time simulation;
- real-time digital simulation;
- controller-HIL (CHIL);
- power-HIL (PHIL);
- hardware prototype/experiment.

Do not use “HIL simulation” as an umbrella term when the actual architecture can be identified. State what is real hardware, what is simulated, and what crosses the interface when this matters to the claim.

## Visual-evidence check
When a claim depends on a figure, table, waveform, diagram, or experimental setup image, inspect the actual visual content when available. Do not judge the claim from the caption or surrounding prose alone. Check axes, units, time windows, legends, baselines, annotations, and whether the displayed evidence actually supports the textual interpretation.

## Figure/table contract
Each core figure/table should answer a research question or support a claim. Check:
- why this visual is needed;
- what condition/comparator/metric it encodes;
- whether units, legends, and labels are self-consistent;
- whether the text adds interpretation rather than reading the axes aloud;
- whether representative cases are actually representative and selection is not misleading.

## Results paragraph contract
Prefer the functional sequence, adapted as needed:
1. question or validation purpose;
2. condition/scenario and comparator;
3. objective observation;
4. quantitative result;
5. comparison against baseline/model/prediction;
6. evaluation of what the magnitude means for the stated objective, when needed;
7. interpretation supported by evidence;
8. claim supported and scope/boundary if needed.

## Observation vs interpretation
Keep distinct:
- **observation**: what data/figure objectively shows;
- **quantification**: magnitude/difference/metric;
- **interpretation**: why it may have occurred;
- **implication**: what it means for the contribution/problem.

Do not turn interpretation into fact without evidence.

## Quantitative-context check
A key number should carry enough context for the reader to understand its engineering meaning. When not self-evident, give the comparator, direction, magnitude of change, target/reference, or relevant operating condition.

Do not create a blanket “every number needs an adjective” rule. Prefer factual comparisons such as “decreased from X to Y” over unsupported evaluative words such as “remarkable” or “substantial”. Statistical significance and engineering significance are different and must not be conflated.

## Detail-weight alignment
Text length, number of figures/tables, and interpretation depth should roughly reflect how important a result is to the manuscript's central claims.
- core contribution evidence deserves enough explanation;
- peripheral results should not dominate the narrative;
- shorter treatment does not justify hiding unfavorable results.

## Figure/table interpretation order
Do not impose one fixed order for “Figure X shows...” and interpretation. Choose the order that minimizes ambiguity:
- for a potentially ambiguous waveform/plot, orient the reader to the intended observation before or immediately after the figure reference;
- for a straightforward visual, a concise figure invitation may come first.

The goal is unambiguous interpretation, not a fixed sentence template.

## Problematic or negative results
Do not hide or rhetorically minimize them. Use:
`disclose → quantify → assess impact → bound affected claim → explain/remedy if supported`.

## Cherry-picking check
If only selected cases are displayed, require a justified selection rule or an aggregate summary when necessary to support the breadth of the claim.
