# Optional Intermediate Records

## Article-type record
- Target journal:
- Article type:
- Officially supported type: yes / no / unknown
- Hard article-type requirements:
- Strong editorial preferences:
- Relevant corpus type:


Use only when they make a complex task clearer. Do not force all records for small edits.

## Gap record
- Research problem:
- Nearest prior work:
- Existing capability:
- Critical assumption/information dependency:
- Target condition:
- Failure/insufficiency:
- Mechanism:
- Technical consequence:
- Unresolved capability:
- Supporting literature:
- Author inference/own evidence:
- Scope:
- Confidence / unresolved verification:

## Contribution record
- Contribution ID:
- Corresponding gap:
- Closest baseline:
- Technical difference:
- New capability/knowledge:
- Why non-trivial:
- Required evidence:
- Available evidence:
- Missing evidence:
- Supported scope:
- Allowed claim strength:

## Claim–evidence ledger
- Claim:
- Type:
- Contribution link:
- Evidence type:
- Evidence location:
- Comparator:
- Metric:
- Valid scope:
- Current wording:
- Allowed wording:
- Status: supported / partial / missing / conflicting

## Validation matrix
- Claim/contribution:
- Research question:
- Scenario:
- Baseline:
- Metric:
- Expected discriminating outcome:
- Actual result:
- Evidence location:
- Scope supported:

## Terminology/notation ledger
- Term/symbol:
- Definition:
- First-use location:
- Unit/base/direction:
- Conflicting usages:
- Resolution:
