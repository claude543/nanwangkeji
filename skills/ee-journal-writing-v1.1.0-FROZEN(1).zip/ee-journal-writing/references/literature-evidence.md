# Literature, Source Evaluation, and Citation Support

## Use when
The task involves literature review, related work, research-gap construction, citation checking, source comparison, or journal-corpus learning.

## Evidence roles
For each cited source, identify the role it actually serves:
- background fact or accepted context;
- definition/standard/official requirement;
- prior technical method or model;
- evidence of an existing limitation/gap;
- comparator/baseline;
- support for a mechanism or interpretation.

Do not cite a paper merely because its title appears related.

## Source hierarchy
Prefer, as appropriate:
1. current official standards, journal/publisher policies, or manufacturer/platform documentation for rules/specifications;
2. original peer-reviewed research for technical claims about methods, results, and limitations;
3. high-quality reviews for orientation, taxonomy, and discovery, then verify decisive claims in primary sources;
4. secondary summaries only when primary material is unavailable and the limitation is stated.

## Claim–reference alignment
Before asserting that a citation supports a claim, verify that the accessible source actually supports the nearby proposition. Distinguish:
- **DIRECT**: source explicitly states or demonstrates the proposition;
- **SUPPORTED INFERENCE**: proposition reasonably follows from source details but is not explicitly stated;
- **UNVERIFIED**: only title/metadata/snippet is available or the support is ambiguous;
- **CONFLICTING**: source evidence does not support or contradicts the proposition.

Do not present SUPPORTED INFERENCE as the cited authors' explicit conclusion. Do not present UNVERIFIED support as established.

## Gap construction
A publishable gap should not rest only on absence-of-search results such as “few studies”. Build the gap from:
`nearest prior capability → key assumption/information dependency → target condition → insufficiency/failure mechanism → technical consequence → unresolved capability`.

Separate:
- what prior papers explicitly report;
- what the author infers from them;
- what the author's own baseline/analysis newly demonstrates.

## Literature synthesis
Synthesize by technical route, assumption, mechanism, information requirement, model class, or capability when this is more informative than author-by-author chronology.

A useful internal matrix may include:
- paper/source;
- problem;
- method/model;
- key assumptions;
- information required;
- validated conditions;
- stated limitation;
- relevance to the present gap.

Do not force a fixed number of citations or recent-year percentage.

## Freshness and scope
When a claim depends on current policy, current standards, current journal rules, or rapidly changing technology, verify it from a current authoritative source. For stable scientific results, prioritize technical relevance and source quality over recency alone.

## Citation placement and ownership
Place a citation close enough to the proposition it supports that the reader can identify the supported content. If one sentence mixes prior work and this paper's contribution, structure the sentence or citation placement so that prior authors do not appear to “own” the present paper's contribution.

A sentence-final citation is not automatically correct when only one clause is supported by that source. Follow target-journal citation-format rules while preserving semantic ownership.

## Citation integrity
- Never fabricate references, DOIs, authors, page numbers, or quotations.
- Never assign a paper a claim that has not been checked against accessible content.
- Do not let a review article substitute for a primary-source verification when the exact method/result matters and the primary source is available.
- Do not copy or closely paraphrase exemplar wording; learn rhetorical function and structure, not sentences.

## Output for literature/gap audits
Prioritize:
1. unsupported or misattributed claims;
2. missing nearest-neighbor work that threatens novelty/gap logic;
3. unsynthesized literature lists;
4. citation-placement or style issues.
