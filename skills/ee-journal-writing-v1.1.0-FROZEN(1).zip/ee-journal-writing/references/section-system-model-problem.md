# System Description, Modeling, and Problem Formulation

## Purpose
Make the technical object, assumptions, equations, information structure, and problem definition precise enough that later claims can be interpreted and validated.

## System boundary
Identify:
- physical components included;
- controllers/communication/optimization layers included;
- components represented by equivalents;
- external grid/environment assumptions;
- relevant timescales.

Flag hidden boundaries or switching between model levels without explanation.

## Assumptions
For each material assumption ask:
- what is assumed;
- why it is reasonable for this study;
- which derivation/result depends on it;
- where the conclusion ceases to apply if it is violated.

Common EE examples include balanced operation, ideal measurements, linearization, constant parameters, neglected losses/dynamics, synchronized communication, or specific converter/grid representations. Do not insert assumptions unless supported by the manuscript.

## Variables, directions, units
Check state/input/output definitions, sign conventions, power-flow directions, reference frames, bases, units, initial/operating points, and sampling/control times.

## Model traceability
For each important equation/model block identify:
- physical/theoretical origin;
- variables and parameters;
- assumptions;
- role in the later method or analysis;
- validity range.

Do not accept equation accumulation with no role in the paper argument.

## Model-role distinction
Distinguish when relevant:
- physical/high-fidelity model;
- control-oriented model;
- small-signal/linearized model;
- optimization model;
- simulation implementation;
- experimental/HIL equivalent.

Do not transfer conclusions across these model roles without justification.

## Problem formulation completeness
The manuscript should make clear:
- current system state/problem;
- desired objective;
- available measurements/information;
- control/decision variables;
- constraints;
- disturbances/uncertainties relevant to the claim;
- optimization/control/estimation target;
- what existing formulation cannot achieve and why.

## Reproducibility
Require enough detail for an expert to reconstruct the essential model/problem setup. Missing low-level implementation detail may be acceptable if it is standard and nonessential; missing claim-critical detail is not.
