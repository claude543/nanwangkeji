# Proposed Method, Algorithm, Theory, and Property Claims

## Method contract
A proposed method should make clear:
- which gap/problem it addresses;
- inputs and information sources;
- outputs/commands/decisions;
- internal states or memory when relevant;
- core mechanism and causal rationale;
- constraints and triggers/switching conditions;
- key parameters and how they are selected;
- initialization and update sequence when needed;
- concrete difference from the nearest baseline/prior method;
- conditions under which the method is expected to work.

## Method credibility
Methodology is not only a record of what was done; it establishes why the later results are credible. For claim-critical choices, provide the real technical rationale, source, constraint, or derivation needed to justify them.

Do not simulate rigor with adverbs such as “carefully”, “thoroughly”, or “appropriately” when the underlying procedure or evidence is not specified. Concrete procedure and rationale are stronger than rhetorical care markers.

When a limitation/problem belongs to the method itself, disclose it where the method is defined if delaying disclosure would mislead the reader.

## Non-triviality check
Do not accept novelty merely because known blocks are combined. Identify the new interaction, mechanism, formulation, property, or capability created by the combination.

## Algorithm reproducibility
A qualified reader should be able to reconstruct the claim-critical logic from the paper. Flag missing:
- update equations;
- state transitions;
- priority/order of operations;
- saturation/constraint handling;
- communication assumptions;
- tuning rules that materially affect reported performance.

## Theory/property routing
Treat different claims separately.

### Stability
Define the stability concept, model, equilibrium/operating point, assumptions, and domain of validity. Simulation can validate behavior but does not replace a proof when the paper claims a proven property.

### Convergence
State what converges, to what, under which initialization/conditions, and whether convergence is finite/asymptotic/practical/etc. Do not use generic convergence language if only empirical settling is shown.

### Robustness/resilience
Identify the uncertainty/disturbance/fault/communication condition and tested or proven range. Avoid unrestricted “robust” claims.

### Optimality
Require an explicit objective, decision variables, constraints, and an appropriate optimality basis. Better numerical performance against baselines is not alone proof of optimality.

### Real-time feasibility
Require timing/resource evidence relevant to the implementation: sampling/control period, execution time/latency, platform, and headroom where material.

### Scalability
Require complexity analysis and/or evidence across changing system size/topology/resources appropriate to the stated claim.

## Claim boundary
Theory proves only what its assumptions and derivation support. Validation demonstrates only what its tested scenarios support. Use the intersection of valid scopes when writing combined conclusions.

For mixed model–method papers, keep separate: (a) evidence that the model/formulation is valid, (b) evidence that the proposed method improves the target behavior, and (c) evidence that the implementation is feasible. A single simulation figure should not silently serve all three roles.
