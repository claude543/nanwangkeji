# Reviewer Mode and Pre-Submission Audit

## Reviewer mode

## Output discipline
Prioritize only issues that materially affect validity, evidence, reproducibility, journal fit, or reader understanding. Do not manufacture a long review to appear thorough. Merge duplicate concerns that share one root cause.

## Concern status and confidence
面向用户时使用中文状态：
- **已确认问题**：在当前材料中可以直接确认。
- **需要进一步核实**：问题可能重要，但当前材料不足以确认其确实缺失或错误。
- **表达优化建议**：不影响技术成立性的非阻断性呈现/风格改进。

只有“已确认问题”或证据较充分的“需要进一步核实”才给严重程度：
- **阻断性问题**：当前无法建立核心贡献或有效性。
- **主要问题**：明显削弱主要论断、证据链、可复现性或期刊匹配。
- **次要问题**：局部问题，不威胁论文主线。

不要把“没有看到”变成“论文没有”。材料不完整时，未显示的证据通常属于“需要进一步核实”，而不是“已确认缺失”。

Evaluate the manuscript from independent lenses. Do not manufacture criticism to fill quotas.

### Core lenses
- journal fit and scope;
- novelty/contribution clarity;
- technical soundness;
- evidence sufficiency and validation design;
- baseline fairness;
- reproducibility;
- interpretation/mechanism quality;
- limitation and scope honesty;
- presentation/organization.

For each major concern provide:
- location;
- exact issue;
- why it matters technically;
- affected claim/contribution;
- evidence or analysis needed to resolve it.

Distinguish **blocking major concerns** from improvements.


## Review stopping rule
Once the central publication case is determined by a small number of root-cause issues, stop expanding the review with repetitive low-impact comments. Merge downstream symptoms under the earliest root cause. Offer a deeper line-by-line pass only when requested.

## Minimal sufficient remedy
Recommend the least burdensome scientifically valid fix. If a claim can be made correct by narrowing scope or weakening wording, do not automatically demand a new experiment. Recommend additional analysis/testing only when the intended major claim genuinely requires it.

## Red-team questions
- What is the strongest alternative explanation for the key result?
- Which contribution has the weakest direct evidence?
- Which claim is broader than the tested/proven scope?
- What baseline would a skeptical reviewer expect?
- Which assumption, if violated, most threatens the conclusion?
- Is any result selectively presented?
- Can an expert reproduce the claim-critical method and tests?

## Pre-submission gates
Run as relevant:
- target-journal official requirements verified;
- title/abstract/conclusion consistent with body;
- contributions mapped to evidence;
- all figures/tables cited and interpretable;
- notation/units/sign conventions consistent;
- citations actually support nearby claims;
- no placeholder or planned result presented as achieved;
- no unsupported strong words;
- limitations and scope boundaries stated where material;
- manuscript source/format requirements satisfied if supplied.

## Re-audit
After major revisions, re-check the affected claims and cross-section consistency rather than assuming fixes remain local.
