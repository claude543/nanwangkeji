# Target-Journal Adaptation

## Trigger
Load when the user names a target journal/publisher or requests journal-specific adaptation.

## Current-source rule
When journal requirements may have changed and web access is available, verify them from the official journal/publisher site rather than relying on memory.


## Official-rule severity
面向用户时把官方要求分成：
- **硬性要求**：明确的投稿资格、文章类型、强制验证/内容、长度、文件或政策要求；不满足不能靠润色解决。
- **明确偏好**：编辑方明确表达、会显著影响组织/重点/证据预期，但并未写成强制条件。
- **格式与风格要求**：模板、标题页、摘要、标题层级、参考文献、图表或文件格式等。

If an official source imposes a technical evidence condition (for example, experiments required for a particular article type), treat it as a validation/submission gate and report it before stylistic adaptation. Never disguise a hard evidence deficiency by rewriting.

## Source priority
1. Current official journal/publisher author instructions, templates, article-type requirements, and policies.
2. Recent papers from the same journal, same article type, and similar research paradigm/topic.
3. Broader field exemplars only when the target corpus is insufficient.
4. General EE/scientific-writing principles.

## Official vs observed rules
Keep separate:
- **Official requirement**: binding unless an editor/template states otherwise.
- **Observed convention**: recurring pattern in comparable recent papers; useful for style adaptation but not mandatory.

Never infer a formal journal rule solely from a few papers.


## Article-type matching
Before learning from a corpus, match the manuscript to the target journal's article type. Do not learn a Regular Paper structure from Letters, Brief Papers, Reviews, Perspectives, or Case Studies unless the user is writing that same type.

For short formats, compress the argument and evidence presentation without deleting claim-critical information. For review/perspective formats, do not force original-research contribution/validation contracts onto the manuscript.

## Corpus selection
Prefer papers that are:
- same journal;
- recent enough to reflect current style;
- same article type;
- technically close in research paradigm;
- sufficiently complete to observe the section under study.

Use enough papers to identify stable patterns; do not hard-code a fixed number. Prefer public/version-of-record full text when available so section-level style is observed rather than inferred from abstracts.

If only abstracts/metadata are accessible, restrict learning to what those sources actually reveal (for example title/abstract density, article type, and broad terminology). Do not infer paragraph-, section-, equation-, figure-, or discussion-style conventions from abstract-only access.


## Corpus-learning confidence and anti-drift
Published papers are evidence of what has appeared in the journal, not proof that every local writing choice is exemplary or required. Prevent style drift as follows:
- match the exact article type before learning structure;
- prefer the same technical paradigm/subcommunity for section-level learning;
- identify themed/special-issue papers and down-weight them unless the manuscript targets that theme;
- exclude editorials, reviews, perspectives, letters, and conference-derived formats when they do not match the manuscript type;
- 对观察到的期刊惯例，面向用户时区分为**稳定惯例**、**多种写法并存**、**个别写法**；
- 不把“多种写法并存”或“个别写法”升级为强制规则；
- if comparable papers disagree, preserve the manuscript's technically clearer form unless an official rule resolves the choice.

## Publication-survivor-bias guard
A published paper may contain weak phrasing, overclaim, incomplete reporting, or an editorially tolerated exception. Never learn technical validity, claim strength, or evidence sufficiency from prevalence alone. Apply the core claim/evidence and domain rules independently.

## Official-policy exception guard
A corpus example cannot cancel an explicit current official policy. If the journal states that a form of evidence is generally required but allows exceptional justification, treat corpus papers using the exception as exceptions, not as a new default. Report the official default first.

## Adaptation depth
Use a light journal route for local wording/section tasks: verify only the official rules and corpus patterns relevant to that request. Do not launch a broad corpus study merely because a journal name is present.
Use a deep journal route only for full-manuscript adaptation, explicit style-profile requests, or pre-submission review.

## Section-specific learning
Learn only what is relevant to the requested section. For example:
- Introduction adaptation: rhetorical pacing, literature balance, contribution placement;
- Method/theory adaptation: heading granularity, equation/explanation balance;
- Validation/results adaptation: figure density, result/discussion separation, caption/detail conventions;
- Abstract/title adaptation: information density and title construction.
Do not create a single journal-wide style average across technically unrelated subfields.

## What to learn dynamically
Depending on task, learn:
- section ordering and heading conventions;
- typical Introduction/literature balance;
- contribution presentation;
- equation/figure/table density and caption style;
- Results vs Discussion separation;
- abstract information density;
- title patterns;
- first-person/passive tendencies;
- paragraph length and rhetorical pacing;
- terminology preferred by the journal community.

## Safeguards
- Do not copy or closely imitate source paper sentences.
- Do not import technical claims or facts from style exemplars into the user's paper.
- Do not let target-journal style override evidence, scope, or technical correctness.
- If current official guidance is unavailable, state that adaptation is corpus-based/general rather than official-rule verified.
