# Integrity and Technical-Fact Protection

## Trigger
Apply to every manuscript-related task.

## Protect before editing
Treat the following as locked unless the user explicitly asks to correct them and evidence supports the correction:
- equations and mathematical relationships;
- numerical results, parameter values, units, signs, directions, thresholds, timings, and percentages;
- variable names, subscripts, superscripts, abbreviations, device names, and terminology;
- figure/table/equation/section labels;
- citation identities and the claim each citation supports;
- stated experimental, simulation, HIL, hardware, and software conditions;
- achieved vs planned vs preliminary status of work.

## Required behavior
- Never invent missing values or silently normalize inconsistent values.
- Never fabricate citations, experiments, measurements, proofs, simulations, or mechanisms.
- Do not convert a planned validation into an achieved result.
- Do not convert correlation/association into causality without sufficient evidence.
- Do not “repair” a technical inconsistency by guessing. Flag it.
- If a rewrite would change technical meaning, present it as a proposed technical change rather than a language edit.

## Evidence status
需要显示给用户时使用中文：
- **已确认事实**：由用户材料或已核实来源直接支持。
- **合理推断**：可以从现有证据推导，但原材料没有直接说出。
- **需要核实**：目前只是可能性，证据不足。

不要把后两类写成既定事实。

## File/parsing caution
If an uploaded PDF/document appears to corrupt equations, subscripts, symbols, tables, or figure content during text extraction, do not diagnose the technical content from the broken parse alone. Inspect the rendered page/figure or request the source when necessary.

## Stop conditions
Stop language polishing and raise the issue when:
- two supplied values or definitions conflict;
- a key equation is dimensionally or logically ambiguous;
- a claimed experiment/result is missing from the supplied evidence;
- the text assigns a claim to a citation that has not been verified;
- a requested rewrite would require creating technical content.


## Source-coverage gate
内部判断材料覆盖度，面向用户时用中文表达：
- **当前任务材料足够**：足以判断当前段落/章节/图表任务。
- **全文材料足够**：足以做全文层面的判断。
- **当前任务材料不足**：完成当前判断所需内容或证据缺失。

某一章节可以“当前任务材料足够”，即使全文并未提供。不要混淆。

当前任务材料不足时：
- audit only claims and structures visible in the supplied material;
- distinguish **detected problem** from **not verifiable from available material**;
- do not infer that missing evidence is absent from the full paper;
- do not issue a definitive manuscript-wide recommendation based only on excerpts.
