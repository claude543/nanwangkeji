# Claim–Evidence–Scope Core

## Purpose
Ensure that the strength and scope of every important manuscript claim are supported by evidence.

## Claim classes
Identify major claims such as:
- novelty / first-of-kind;
- improved performance;
- stability / convergence;
- robustness / resilience;
- optimality;
- real-time feasibility;
- scalability / generality;
- mechanism / causality;
- reproducibility / accuracy;
- superiority over baselines.

## First classify the claim
Classify the claim before judging evidence. Typical classes include:
- model/formulation validity or accuracy;
- method/controller performance;
- theoretical property (stability, convergence, optimality, bounds);
- mechanism/causality;
- implementation/real-time feasibility;
- hardware/topology performance;
- system-level capability or generality.

Do not let evidence for one class silently support another class.

## Proportionality
Apply the full claim ledger to major contribution-bearing or high-risk claims. Do not create a heavy evidence record for every routine descriptive sentence. Use the lightest check that can prevent a meaningful overclaim.

## For each major claim, establish
1. **Claim**: exact proposition being asserted.
2. **Contribution link**: which contribution it supports.
3. **Evidence type**: literature, derivation/proof, simulation, experiment, HIL, hardware, benchmark, complexity analysis, or other.
4. **Evidence location**: section/equation/figure/table/test.
5. **Comparator**: if comparative, what baseline/reference is used and whether comparison is fair.
6. **Scope**: system, operating point, parameter range, disturbance, communication condition, timescale, platform, and validation type actually covered.
7. **Allowed wording**: strongest language justified by the evidence.
8. **Gap**: missing evidence or unsupported extension.

## Evidence-strength rules
- A stable-looking waveform is not by itself a proof of stability.
- A few tested cases do not by themselves justify broad “robust”, “general”, or “scalable” claims.
- “Optimal” requires a defined optimization problem and appropriate optimality basis.
- “Real-time” requires evidence related to execution/latency/sampling constraints on a relevant platform.
- “Significant” must not imply statistical significance unless statistical testing supports it.
- “First” requires careful, current literature verification and still does not constitute technical significance by itself.
- A mechanism claim needs evidence that distinguishes it from plausible alternatives, not only correlation.
- A model validated only against a simulation sharing the same core assumptions primarily demonstrates self-consistency; do not automatically call it independent physical validation.
- A performance simulation does not by itself establish a theoretical guarantee. Words such as `guarantee` or `ensure` require a formal basis, explicit invariant/constraint argument, or equivalent evidence appropriate to the claim.
- A hardware/HIL demonstration may strengthen implementation evidence but does not automatically prove novelty, stability, robustness, or generality.

- A proxy metric does not automatically establish a downstream engineering benefit. For example, a higher SOC at one instant does not by itself prove higher efficiency, longer battery life, greater flexibility, or better reserve capability. Trace `measured metric → physical/operational interpretation → claimed benefit`, and require evidence for each non-trivial link.
- Constraint-satisfaction claims such as “prevents overcharge”, “avoids limit violation”, or “ensures stable operation” require a defined constraint, tested/proven condition range, and relevant time horizon. A finite scenario demonstrates only the tested range unless a formal invariant or equivalent argument is provided.

## Decision rule
If evidence is weaker than the claim:
- narrow the scope;
- weaken the wording;
- mark evidence needed; or
- recommend an additional analysis/test.
Never solve the mismatch by rhetorical strengthening.

## High-risk words
On encountering these, trigger evidence review rather than automatic deletion:
`novel`, `first`, `robust`, `optimal`, `stable`, `guarantee`, `ensure`, `general`, `scalable`, `real-time`, `significant`, `superior`, `outperform`, `prove`.
