# Introduction, Literature Map, Gap, and Contributions

## Required functions
An EE Introduction should normally establish, in an order appropriate to the target journal:
1. technical context and why the problem matters;
2. the specific technical problem;
3. a synthesized map of relevant existing approaches;
4. the unresolved technical gap and its consequence;
5. how the present work responds to that gap;
6. contribution claims that create explicit evidence obligations.

Do not enforce a fixed paragraph count.

## Background relevance gate
For each background statement ask: if removed, would the reader lose information necessary to understand the specific problem/gap? Remove or compress generic macro-background that does not connect to the technical variables or mechanism.

## Literature synthesis
Prefer organization by technical route, assumption, model, information dependency, or capability rather than author-by-author chronology unless chronology is technically meaningful.

Each cited work should mainly serve one or more roles:
- support a background fact;
- map an existing technical approach/capability;
- support the gap or limitation being discussed.

## Valid gap record
A strong gap should identify:
- target problem;
- nearest prior work;
- what prior work can already do;
- its critical assumption/information dependency;
- target condition of this paper;
- what becomes insufficient or fails;
- technical mechanism for the insufficiency;
- resulting consequence;
- unresolved capability needed;
- literature evidence vs author's own inference/observations;
- scope in which the gap is claimed.

### Reject or downgrade weak gap patterns
- “few studies investigated X” without technical necessity;
- merely moving an existing method to a new application;
- lack of HIL/experiment when validation is the only novelty;
- vague “performance can be improved” without mechanism;
- combining known blocks without a new interaction/mechanism/capability;
- “first” used as a substitute for technical value.

## Gap-to-method correspondence
Every core method element should answer a diagnosed problem, and every core gap should receive a method response. Flag ornamental modules or unresolved gaps.

## Contribution record
For each contribution identify:
- corresponding gap;
- closest baseline/prior method;
- concrete technical difference;
- new capability or new knowledge enabled by that difference;
- why the difference is non-trivial;
- required evidence;
- available evidence;
- missing evidence;
- supported scope;
- allowed claim strength.

Do not treat “we designed X”, “we conducted HIL”, or “we performed simulations” as contributions by themselves. These are actions or validation methods unless they embody a new technical capability.

## Reverse-outline check
Read only the first sentence/topic function of each paragraph. The sequence should still show a coherent narrowing from context to problem to existing approaches to gap to present work.

## Output
For drafting: build the logical map first, then prose.
For audits: identify the earliest broken link; fixing downstream wording before the gap/contribution logic is stable is low priority.
