# Revision and Response to Reviewers/Editors

## Use when
The user asks to revise a manuscript after peer review, respond to editor/reviewer comments, prepare a rebuttal/response letter, or check consistency between revisions and the response.

## Core rule
The response letter must describe what was actually changed or why a requested change was not made. Never claim a revision, experiment, citation, analysis, or manuscript location that does not exist.

## Workflow
1. Separate editor instructions from individual reviewer comments.
2. Give each comment a stable ID (for example E1, R1-1, R2-3) if the source does not already provide one.
3. Classify each comment by impact: technical validity, evidence, scope/claim, literature, reproducibility, organization, language/style, or journal-policy issue.
4. Identify which manuscript claim/section/evidence the comment affects.
5. Decide the scientifically valid action before drafting the response:
   - revise manuscript;
   - add analysis/evidence if genuinely necessary and available;
   - narrow/clarify a claim;
   - explain existing evidence more clearly;
   - respectfully disagree with evidence/reasoning.
6. Update the manuscript first when possible, then draft the response from the actual change.
7. Re-audit affected claims and cross-section consistency after major revisions.

## Response structure
For each comment, use only the elements needed:
- concise acknowledgment of the concern;
- direct answer/position;
- what changed and why;
- exact manuscript location when known;
- supporting evidence/citation when relevant.

Avoid empty gratitude, defensive tone, or long restatement of the reviewer comment.

## Disagreement
When disagreeing:
- state the technical reason directly and respectfully;
- support it with manuscript evidence, derivation, data, or verified literature;
- clarify the manuscript if the original wording plausibly caused the misunderstanding;
- do not imply that reviewer misunderstanding alone proves the manuscript was already clear.

## Consistency checks
Verify that:
- response claims match actual revised text/data;
- line/page/section references are current;
- new analyses/results are reflected in Abstract/Conclusion/Contributions if they materially change the paper;
- narrowed claims are narrowed everywhere, not only in the response letter;
- added citations support the exact claims assigned to them;
- no reviewer request is silently omitted.

## Output
Default to a traceable comment-by-comment response. If the user has not yet revised the manuscript, separate **proposed manuscript change** from **draft response wording**.
