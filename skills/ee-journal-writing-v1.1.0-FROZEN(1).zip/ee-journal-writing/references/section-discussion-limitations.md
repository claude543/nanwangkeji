# Discussion and Limitations

## Discussion purpose
Discussion should explain what the supported results mean for the technical problem and existing knowledge. It should not merely restate curves, tables, or contribution bullets.

## Core discussion moves
Use only those needed:
- revisit the research question/claim;
- identify the most informative result;
- explain the physical/control/mathematical mechanism;
- compare with prior theory or findings;
- explain agreements/disagreements;
- distinguish supported mechanism from plausible alternatives;
- state what new understanding or capability follows;
- state what does not follow;
- define the validity boundary.

## Mechanism standard
Prefer explanations tied to equations, control logic, physical processes, measurements, or independent evidence. Avoid post-hoc narratives that merely sound plausible.

## Mapping vs contribution
Keep distinct:
- **mapping**: how the findings relate to existing work;
- **contribution**: what new capability/knowledge this paper establishes.

## Callback consistency
When Discussion revisits the research question, gap, method, or key result:
- use the same core technical terminology unless the concept genuinely changes;
- preserve notation and claim scope;
- do not introduce a new method fact, experimental fact, parameter, or result for the first time as part of a callback.

Controlled repetition is preferable to synonym variation when synonym variation could make one concept look like two.

## Limitations contract
For each material limitation identify:
- limitation;
- cause/source;
- affected claim or result;
- severity/impact if known;
- validity boundary created;
- mitigation or future work if justified.

Do not write limitations as ritual self-criticism and do not hide them with vague positive language.

## Future work
Future work should follow from a real unresolved limitation, boundary, or new question. Do not use future work to retroactively cover missing evidence required for a current major claim.
