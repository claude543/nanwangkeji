# Cross-Section Consistency, Terminology, and Notation

## Cross-section contract
Check that:
- the Introduction's problem and gap are addressed by the proposed method;
- each stated contribution has corresponding method content and validation evidence;
- validation scenarios test the conditions under which contributions are claimed;
- Results support, rather than merely resemble, the claimed contribution;
- Discussion interprets only supported results;
- Conclusion and Abstract do not introduce stronger or new claims;
- title scope matches the actual paper scope.

## Terminology ledger
Track important terms and enforce one meaning per term. Flag:
- multiple names for the same object without reason;
- one term used for different objects;
- undefined abbreviations;
- inconsistent capitalization of technical terms;
- changes between “command”, “reference”, “measurement”, “estimate”, “state”, and “actual execution” when these are technically distinct.

## Notation ledger
Check:
- every symbol is defined at first appropriate use;
- vector/matrix/scalar notation is consistent;
- subscripts/superscripts are stable;
- sign conventions and reference directions are explicit where needed;
- SI/pu bases and unit conventions are clear;
- equations and prose use the same symbol for the same quantity;
- reused symbols do not create ambiguity.

## Figures/tables
Check consistency of:
- labels, legends, variable names, units, acronyms;
- operating-condition names;
- baseline names;
- numbering and textual references.

## Output
For audits, prioritize inconsistencies that could alter technical interpretation above cosmetic notation issues.
